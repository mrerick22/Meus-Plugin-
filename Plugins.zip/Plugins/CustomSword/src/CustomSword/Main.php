<?php

declare(strict_types=1);

namespace CustomSword;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\form\Form;
use pocketmine\utils\TextFormat;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info(TextFormat::GREEN . "CustomSwords Plugin carregado!");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "customsword") {
            if (!$sender instanceof Player) {
                $sender->sendMessage(TextFormat::RED . "Este comando só pode ser usado por jogadores!");
                return false;
            }

            if (!$sender->hasPermission("customswords.use")) {
                $sender->sendMessage(TextFormat::RED . "Apenas OPs podem usar este comando!");
                return false;
            }

            $this->showCustomSwordForm($sender);
            return true;
        }
        return false;
    }

    private function showCustomSwordForm(Player $player): void {
        $form = new CustomSwordForm($this);
        $player->sendForm($form);
    }

    public function createCustomSword(Player $player, string $name, int $damage, int $durability, string $material): void {
        // Obter a espada baseada no material
        $sword = $this->getSwordByMaterial($material);
        
        // Definir nome customizado
        $sword->setCustomName(TextFormat::colorize($name));
        
        // Adicionar lore com informações
        $lore = [
            TextFormat::GRAY . "Espada Personalizada",
            TextFormat::YELLOW . "Dano: " . TextFormat::WHITE . $damage,
            TextFormat::YELLOW . "Durabilidade: " . TextFormat::WHITE . $durability,
            TextFormat::YELLOW . "Material: " . TextFormat::WHITE . $material,
            TextFormat::DARK_GRAY . "ID: " . $damage . "-" . $durability
        ];
        $sword->setLore($lore);
        
        // Definir quantidade
        $sword->setCount(1);
        
        // Dar item ao jogador
        if ($player->getInventory()->canAddItem($sword)) {
            $player->getInventory()->addItem($sword);
            $player->sendMessage(TextFormat::GREEN . "Espada personalizada criada com sucesso!");
        } else {
            $player->sendMessage(TextFormat::RED . "Inventário cheio! Não foi possível criar a espada.");
        }
    }

    private function getSwordByMaterial(string $material): Item {
        switch (strtolower($material)) {
            case "madeira":
                return VanillaItems::WOODEN_SWORD();
            case "pedra":
                return VanillaItems::STONE_SWORD();
            case "ferro":
                return VanillaItems::IRON_SWORD();
            case "ouro":
                return VanillaItems::GOLDEN_SWORD();
            case "diamante":
                return VanillaItems::DIAMOND_SWORD();
            case "netherite":
                return VanillaItems::NETHERITE_SWORD();
            default:
                return VanillaItems::IRON_SWORD();
        }
    }

    // Event listener simples para dano customizado
    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        
        if (!$damager instanceof Player) {
            return;
        }
        
        $item = $damager->getInventory()->getItemInHand();
        $lore = $item->getLore();
        
        // Verificar se é uma espada customizada pela lore
        if (empty($lore) || !isset($lore[0]) || $lore[0] !== TextFormat::GRAY . "Espada Personalizada") {
            return;
        }
        
        // Extrair dano da lore
        if (isset($lore[1])) {
            $damageText = $lore[1];
            preg_match('/Dano: §f(\d+)/', $damageText, $matches);
            
            if (isset($matches[1])) {
                $customDamage = (int)$matches[1];
                $event->setBaseDamage($customDamage);
            }
        }
    }
}

class CustomSwordForm implements Form {
    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function jsonSerialize(): array {
        return [
            "type" => "custom_form",
            "title" => "§6Criar Espada Personalizada",
            "content" => [
                [
                    "type" => "input",
                    "text" => "§eNome da Espada:",
                    "placeholder" => "Digite o nome da espada...",
                    "default" => "Espada Épica"
                ],
                [
                    "type" => "input",
                    "text" => "§eDano da Espada:",
                    "placeholder" => "Digite o dano (ex: 10, 100, 1000)",
                    "default" => "10"
                ],
                [
                    "type" => "slider",
                    "text" => "§eDurabilidade:",
                    "min" => 50,
                    "max" => 5000,
                    "step" => 50,
                    "default" => 1000
                ],
                [
                    "type" => "dropdown",
                    "text" => "§eMaterial da Espada:",
                    "options" => [
                        "Madeira",
                        "Pedra", 
                        "Ferro",
                        "Ouro",
                        "Diamante",
                        "Netherite"
                    ],
                    "default" => 2
                ]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) {
            return;
        }

        try {
            $name = (string)$data[0];
            $damageInput = (string)$data[1];
            $durability = (int)$data[2];
            $materials = ["Madeira", "Pedra", "Ferro", "Ouro", "Diamante", "Netherite"];
            $material = $materials[$data[3]];

            // Validações
            if (empty($name) || strlen($name) > 50) {
                $player->sendMessage(TextFormat::RED . "Nome inválido! Use entre 1 e 50 caracteres.");
                return;
            }

            // Validar dano: deve ser um número inteiro positivo
            if (!ctype_digit($damageInput) || ($damage = (int)$damageInput) < 1) {
                $player->sendMessage(TextFormat::RED . "Dano inválido! Deve ser um número inteiro maior ou igual a 1.");
                return;
            }

            if ($durability < 50 || $durability > 5000) {
                $player->sendMessage(TextFormat::RED . "Durabilidade deve estar entre 50 e 5000!");
                return;
            }

            // Criar a espada
            $this->plugin->createCustomSword($player, $name, $damage, $durability, $material);

        } catch (\Exception $e) {
            $player->sendMessage(TextFormat::RED . "Erro ao processar formulário!");
            $this->plugin->getLogger()->error("Erro no formulário: " . $e->getMessage());
        }
    }
}